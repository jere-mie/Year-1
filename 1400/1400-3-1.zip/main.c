#include <stdio.h>

int main(void) {
  printf("Hello!\n");
  printf("My name is: ** Jeremie Bornais **\n");
  printf("Field of Study: “ Computer Science “\n");
  printf("Thanks :)\n");

  return 0;
}