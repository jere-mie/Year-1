/*
Jeremie Bornais
110007408
University of Windsor
COMP1400
Nine-Gaps Part 2
*/



#include <stdio.h> // C Standard Library for input/output functions
#include <stdlib.h> // C Standard Library for some utility functions,
// such as rand()
#include <time.h> // C Standard Library for date and time functions
// Here you will later on (in the next assignments) declare some variables
// to use them inside the program

int main(void) {
  int i=0;
  int numGrid=1;
  int numRow;
  int numColumn;
  int difficulty;
  int choice;

  // Show a Welcome message to the player.
  printf("Welcome to Nine-Gaps game!...\n");
  printf("*****************************\n");
  printf(" ***************** \n");
  printf(" ***** \n");
  printf(" * \n");



  // Start the outer loop to ask the level of difficulty from the
  // player. This loop gives the player the opportunity to play again
  // after the game is over. Complete this part:

  while(i==0){



    // Ask the player to select the level of difficulty of the game, and
    // check the validity of the user’s input. If the user enters an
    // invalid level, program should provide a proper message and
    // control should go the beginning of the outer loop. Complete
    // this part:

    printf("Please Select a Difficulty:\n");
    printf("1 (Easy)\n");
    printf("2 (Intermediate)\n");
    printf("3 (Advanced)\n");
    printf("4 (Expert)\n");

    scanf ("%d", &difficulty);
    
    
    if (difficulty<1 || difficulty>4){
      printf("Invalid input\n\n\n");
      continue;
    }



    // Start the inner loop to repeatedly ask the player to enter a value
    // between 1 and 9, and selected row and column, each one between 1
    // and 3. (The sentinel value is 0). If the inputs are not valid, show
    // a proper message and control should go the beginning of the inner loop.
    //Complete this part:

    while (numGrid!=0){
      printf("Enter Grid Number from 1-9:\n");
      printf("Enter 0 here to exit\n\n\n");
      
      scanf("%d", &numGrid);
      if (numGrid==0){
        continue;
      }
      if (numGrid>9 || numGrid<1){
        printf("Invalid Grid Number, must be between 1 and 9\n\n\n");
        continue;
      }
      printf("Enter Row Number from 1-3:\n");
      scanf("%d", &numRow);
      if (numRow>3 || numRow<1){
        printf("Invalid Row Number, must be between 1 and 3\n\n\n");
        continue;
      }
      printf("Enter Column Number from 1-3:\n");
      scanf("%d", &numColumn);
      if (numColumn>3 || numColumn<1){
        printf("Invalid Column Number, must be between 1 and 3\n\n\n");
        continue;
      }



      // Show a success or fail message and end the inner loop. Complete
      // this part:

      //just a random number chosen,
      //later on, this will correspond to a real value in an array
      if (numGrid==2){
        printf("Success! you entered the correct number!\n\n\n");
      }else{
        printf("Sorry! that wasn't the correct number!\n\n\n");
      }
    }

    //resetting the sentinel value in case the user wishes to play again
    numGrid=1;



    // Ask the player if s/he wants to play again. If yes, control should
    // go to the beginning of the outer loop. Otherwise, loop will end and
    // program should exit after showing a Goodbye message to the player.
    // Complete this part:
    
    printf("Do you want to play again? 1=yes 2=no\n\n\n");
    scanf("%d", &choice);
    if (choice==2){
      break;
    }else if (choice==1){
      continue;
    }
  }
  printf("Goodbye! Thanks for playing!\n");
  return 0;
}