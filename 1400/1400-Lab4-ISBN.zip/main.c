#include <stdio.h>

int main(void) {
  printf("Enter The First 12 Digits:\n");
  int d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12;
  int checknum;
  int multsum;
  scanf("%1d %1d %1d %1d %1d %1d %1d %1d %1d %1d %1d %1d", &d1, &d2, &d3, &d4, &d5, &d6, &d7, &d8, &d9, &d10, &d11, &d12);
  multsum = d1+3*d2+d3+3*d4+d5+3*d6+d7+3*d8+d9+3*d10+d11+3*d12;
  checknum = 10-(multsum%10);
  printf("Check digit is: %d", checknum);
  return 0;
}
//978030640615