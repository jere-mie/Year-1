#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(void) {
  srand(time(NULL));
  printf("Hello World\n");
  int nums[]={1,2,3,4,5};
  int j, temp;
  for (int i=0;i<5;i++){
    j = rand()%5;
    temp = nums[i];
    nums[i]=nums[j];
    nums[j]=temp;
  }

  for (int l=0;l<5;l++){
    printf("%d ", nums[l]);
  }


  return 0;
}