#include <stdio.h>
int main(void)
{
  { 
    int x = 10;
  }
 
  { 
    printf("%d", x);
  }
}

/*
Output:

main.c:9:18: error: use of undeclared identifier 'x'
    printf("%d", x);
                 ^
1 error generated.
compiler exit status 1

*/