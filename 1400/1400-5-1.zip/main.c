#include <stdio.h>

int main(void) {
  
  
  printf("Exercise 1:\n");
  int sum = 0;
  int added = 0;
  float average = 0;
  printf("Please input 10 numbers:\n");
  for (int i=0;i<10;i++){
    scanf("%d", &added);
    sum+=added;
  }
  average = sum/10.0;
  printf("Sum is: %d\n", sum);
  printf("Average is: %f\n", average);




  printf("Exercise 2:\n");
  printf("Input your number:\n");
  int num2;
  scanf("%d", &num2);
  int isPrime=0;
  for (int i=2;i<num2;i++){
    if (num2%i==0){
      isPrime = 1;
    }
  }
  if (num2 == 1){
    isPrime = 1;
  }  
  if (isPrime==1){
    printf("%d is not a prime number\n", num2);
  }else {
    printf("%d is a prime number\n", num2);
  }






printf("Please enter the number of rows:\n");
int numRows=0;
scanf("%d", &numRows);
for (int i=0;i<=numRows;i++){
  for (int j=0;j<i;j++){
    printf("*");
  }
  printf("\n");
}




printf("Exercise 4:\n");
int multiplier = 0;
printf("Please enter the number:\n");
scanf("%d", &multiplier);
for (int i=1;i<=10;i++){
  printf("%d X %d = %d\n", multiplier, i, multiplier*i);
}




printf("Exercise 5:\n");
char days[7][40] = 
{
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thurday",
  "Friday",
  "Saturday",
  "Sunday"
};

int day;
printf("What day do you want to see:\n");
scanf("%d", &day);
printf("%s", days[day-1]);




  return 0;
}