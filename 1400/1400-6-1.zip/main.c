#include <stdio.h>

int main(void) {
/* 
  //a   
  int i = 1;
  while(i<=136){
    printf("%d*",i);
    i *= 3;
  }
  //1*3*9*27*81*
*/
/*
  //b) 
  int x=11;
  while( x <= 20) {
    if( x % 5 == 0)
      printf("%d\n", x++);
    else
      printf("%d---", x++);
  }
  //11---12---13---14---15
  //16---17---18---19---20
*/

/*
  //c) 
  int i = 3;
  int j = 7;
  while(++i < j--)
    printf("%d-%d\n",i,j);
  //4-6
  //5-5

*/

/*
  //d) 
  int i;
  int n=20; 
  int result=0;
  for (i=1;i<=n; i++)
    result += 1;
  printf("%d",result);
*/
//20

/*
  //e) 
  unsigned int i= 5;
  for (; i>=0 ;i--)
    printf("%d\n",i);
*/
//always true so goes on forever



/*
  //f) 
  int i = 1;
  int a = 0;
  printf("Sum of %d ",i);
  do
  { a = a + i;
  i++;
  }
  while(i <= 5);
  printf("to %d is %d", --i, a);
  */
  //Sum of 1 to 5 is 15
 
/*
SUM OF OUTPUT
-------------
A)
1*3*9*27*81*

B)
11---12---13---14---15
16---17---18---19---20

C)
4-6
5-5

D)
20

E)
always true so goes on forever

F)
Sum of 1 to 5 is 15
*/
  return 0;
}