#include <stdio.h>

int main(void) {
  printf("x value\t expressions\t results\n");
  printf("| 5   |\t | y= x+ 3 |\t | y= 8 |\n");
  printf("| 10  |\t | y= x+ 5 |\t | y= 15|\n");
  return 0;
}