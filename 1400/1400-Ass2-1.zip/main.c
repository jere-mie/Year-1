#include <stdio.h> // C Standard Library for input/output functions
#include <stdlib.h> // C Standard Library for some utility functions,
// such as rand()
#include <time.h> // C Standard Library for date and time functions
// Here you will later on (in the next assignments) declare some variables
// to use them inside the program
int main(void) {
  // Show a Welcome message to the player.
  printf("Welcome to Nine-Gaps game!...\n");
  printf("*****************************\n");
  printf(" ***************** \n");
  printf(" ***** \n");
  printf(" * \n");
  
  // Start the outer loop to ask the level of difficulty from the
  // player. This loop gives the player the opportunity to play again
  // after the game is over. Complete this part:
  int choice =0;
  while (choice==0){


  // Ask the player to select the level of difficulty of the game, and
  // check the validity of the user’s input. If the user enters an
  // invalid level, program should provide a proper message and
  // control should go the beginning of the outer loop. Complete
  // this part:
  printf("Please Select a Difficulty:\n");
  printf("1 (Easy)\n");
  printf("2 (Intermediate)\n");
  printf("3 (Advanced)\n");
  printf("4 (Expert)\n");
  int difficulty;
  scanf("%d", &difficulty);
  if (difficulty>4||difficulty<1){
    printf("Error: Difficulty out of range. Please choose again\n");
    }  
  else{
  
  

  // Start the inner loop to repeatedly ask the player to enter a value
  // between 1 and 9, and selected row and column, each one between 1
  // and 3. (The sentinel value is 0). If the inputs are not valid, show
  // a proper message and control should go the beginning of the inner loop.
  //Complete this part:
    int numRemaining = 9;
    while (numRemaining!=0){

  // Show a success or fail message and end the inner loop. Complete
  // this part:


  // Ask the player if s/he wants to play again. If yes, control should
  // go to the beginning of the outer loop. Otherwise, loop will end and
  // program should exit after showing a Goodbye message to the player.
  // Complete this part:
      }
    }
  }
}