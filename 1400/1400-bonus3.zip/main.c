#include <stdio.h>
#include <math.h>

int main(void) {
  printf("Please enter a number:\n");
  int num;
  int isPrime=1;
  scanf("%d", &num);
  for (int i=2; i<sqrt(num); i++){
    if (num%i==0){
      isPrime = 0;
    }
  }
  switch(isPrime){
    case 0:
      puts("Not Prime");
      break;
    case 1:
      puts("Prime");
      break;
  }
  return 0;
}