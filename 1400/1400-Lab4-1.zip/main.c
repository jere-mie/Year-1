#include <stdio.h>

int main(void) {
  int num1=0; 
  int num2=0;
  printf("Exercise 1\n");
  printf("Input 2 integers:\n");
  scanf("%d", &num1);
  scanf("%d", &num2);
  printf("The remainder of %d, divided by %d is: %d\n", num1, num2, num1%num2);
  printf("Exercise 2\n");
  printf("Input an integer:\n");
  int num3 = 0;
  scanf("%d", &num3);
  if (num3%2==0){
    printf("%d is even\n", num3);
  }else{
    printf("%d is odd\n", num3);
  }
  printf("Exercise 3\n");
  printf("Please enter the year\n");
  int year=0;
    scanf("%d", &year);
  if(year%100!=0){
    if (year%4==0){
      printf("%d is a leap year\n", year);
    }else{
      printf("%d is not a leap year\n", year);
    }
  }else{
    if (year%400==0){
      printf("%d is a leap year\n", year);
    }else{
      printf("%d is not a leap year\n", year);
    }
  }
  printf("Exercise 4\n");
  printf("Please enter 3 numbers:\n");
  int num4, num5, num6;
  scanf("%d", &num4);
  scanf("%d", &num5);
  scanf("%d", &num6);
  int min, max;
  //finding  min
    if(num4<=num5 && num4<=num6){
      min=num4;
    }
    if(num5<=num4 && num5<=num6){
      min=num5;
    }
    if(num6<=num5 && num6<=num4){
      min=num6;
    }
    //finding max
    if(num4>=num5 && num4>=num6){
      max=num4;
    }
    if(num5>=num4 && num5>=num6){
      max=num5;
    }
    if(num6>=num5 && num6>=num4){
      max=num6;
    }
  printf("Max is: %d\n", max);
  printf("Min is: %d\n", min); 
  return 0;
}