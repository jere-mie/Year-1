#include <stdio.h>
unsigned long long int factorial(int n){
  unsigned long long int ans = 1;
  for (int i=0;i<n;i++){
    ans*=(n-i);
  }
  return ans;
}
int main(void) {
  /*printf("Enter number:\n");
  int num;
  scanf("%d", &num);
  printf("%llu", factorial(num));
  */
  for (int i=0; i<70; i++){
    printf("%d! = %llu\n", i, factorial(i));
  }

  /*
  printf("Factorial of %d is %llu\n", 2, factorial(2));
  printf("Factorial of %d is %llu\n", 3, factorial(3));
  printf("Factorial of %d is %llu\n", 4, factorial(4));
  printf("Factorial of %d is %llu\n", 5, factorial(5));
  printf("Factorial of %d is %llu\n", 10, factorial(10));
  printf("Factorial of %d is %llu\n", 15, factorial(15));
*/

  //max value is 65
  return 0;
}