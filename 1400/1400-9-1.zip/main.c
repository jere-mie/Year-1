/*
x = 1, y = 2, z = 3
x = 10, y = 15.000000, z = 4
x = 10, y = 15.000000, z = 50
*/
#include<stdio.h>
int main(void)
{
  int x=1, y=2, z=3;// complete this line
  printf(" x = %d, y = %d, z = %d \n", x, y, z);
  {
      x=10, z = 4;// complete this line
      float y = 15;// complete this line
      printf(" x = %d, y = %f, z = %d \n", x, y, z);
      {
        z=50;// complete this line
        printf(" x = %d, y = %f, z = %d \n", x, y, z);
      }
  }
} 