/*
Jeremie Bornais
COMP 1400 Lab 6 Part 2
10/30/2019
University of Windsor
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

  
int main(void) {
  srand (time(NULL));
  //formula to find random numbers in a given range
  //rand() % (max_number + 1 - minimum_number) + minimum_number
  

  //variable declarations
  int a = rand() % (50 + 1); //the random number
  int guess = -1; //the guess inputted from the user, initialized as out of bounds
  int guessed = 0; //boolean (1 or 0) depending on whether the player has guessed the number
  int numGuesses = 0; //the number of guesses

  //while loop to iterate through guesses
  while (numGuesses<10)
  {
    numGuesses++;
    //getting the guess from the user
    printf("Please enter a guess\n");
    scanf("%d", &guess);

    //seeing if the number has been guessed  
    if (guess==a)
    {
      guessed=1;//saying that the number is guessed
      break;//exiting the loop
    }else if (guess>a)
    {
      printf("Too high\n");
    }else
    {
      printf("Too low\n");
    }
  }

  //depending on if the number has been guessed, we output different messages
  switch (guessed)
  {
    case 0:
        printf("Sorry! You didn't guess the number in time. The number was %d", a);
        break;
    case 1:
        printf("Correct! You guessed the number in %d guesses", numGuesses);
        break;
  }
 
  return 0;
}