/*
Jeremie Bornais
110007408
University of Windsor
11/04/2019
Assignment 3 Part 1
COMP 1400
*/

#include <stdio.h>

int main(void) {

  //I did this so we could simulate an m by n matrix generally
  //instead of assuming it's 3 by 3

  //NOTE: I used 0-indexed rows and columns, 
  //1-indexed would be slightly different
  printf("Input number of rows:\n");
  int n;
  scanf("%d", &n);
  printf("Input number of columns:\n");
  int m;
  scanf("%d", &m);


  int size = n*m;//size of the 1-D array
  int arr [size];

  //initializing to 0 so we can print the array, and demonstrate the simulation visually
  for(int j=0;j<n*m;j++){
    arr[j]=0;
  }

  //input from the user
  int row;
  int column;
  int value;

  printf("Please enter the row, column, and value to be inputted\n");
  scanf("%d%d%d", &row, &column, &value);
  
  //converting from 2D position to 1D position
  int pos = (row*m)+column;

  //setting the value in the given position
  arr[pos] = value;

  //displaying the position
  printf("\n\n%d is in position %d in the array\n\n", value, pos);

  //displaying the matrix
  for (int i=0; i<n*m; i++){
    if ((i+1)%m==0){
      printf("%d\n", arr[i]);
    }else{
      printf("%d ", arr[i]);
    }
  }
  return 0;
}