#include <stdio.h>
#define pi 3.1415926

float computeArea(float rad){
  return rad*rad*pi;
}

int main(void) {
  printf("Please enter the radius:\n");
  float radius, area;
  scanf("%f", &radius);
  area = computeArea(radius);
  printf("Area is: %f", area);
  
  return 0;
}