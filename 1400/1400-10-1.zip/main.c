/*
Jeremie Bornais
University of Windsor
11/27/2019
COMP 1400
Lab Assignment 10
Caesar Cypher
*/

#include <stdio.h>
#define MAX 32

//encrypt and decrypt functions
void encrypt(char a[], int key);
void decrypt(char a[], int key);


int main(void) {

  //getting the string
  printf("Enter Message: ");
  char word[MAX];
  fgets(word, MAX, stdin);
  
  //getting the key
  printf("Enter key: ");
  int key;
  scanf("%d", &key);
  printf("\nBefore Encryption: %s\n", word);

  //encrypting string and displaying it
  encrypt(word,key);
  printf("After Encryption: %s\n",word);

  //decrypting string and displaying it
  decrypt(word, key);
  printf("After Decryption: %s\n",word);
  
  return 0;
}


void encrypt(char a[], int key){
  
  //so long as the string is not empty
  for (int i=0; a[i]!='\0'; i++){

    //iterating through the key
    for (int j=0; j<key; j++){

      //checking that the character is a letter
      if ((a[i]>='a' && a[i]<='z') || (a[i]>='A'&& a[i]<='Z')){
        
        //used to loop back around if we reach the end of the alphabet
        if (a[i]=='z'){
          a[i]='a';
        }else if (a[i]=='Z'){
          a[i]='A';
        }else{
          //shifting place one up
          a[i]++;
        }
      }
    }
  }
}

void decrypt(char a[], int key){
  
  //so long as the string is not empty
  for (int i=0; a[i]!='\0'; i++){

    //iterating through each step of the key
    for (int j=0; j<key; j++){

      //making sure it is a letter
      if ((a[i]>='a' && a[i]<='z') || (a[i]>='A'&& a[i]<='Z')){
        
        //used to loop back around if the letter reaches the end of the alphabet
        if (a[i]=='a'){
          a[i]='z';
        }else if (a[i]=='A'){
          a[i]='Z';
        }else{
          //shifting place one left
          a[i]--;
        }
      }
    }
  }
}