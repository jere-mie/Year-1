#include <stdio.h>

void toBinary(int n){
  int binary[32];
  int i=0;
  while(n!=0){
    binary[i]=n%2;
    n/=2;
    i++;
  }
  
  for (int j=i-1; j>=0; j--){
    printf("%d", binary[j]);
  }
  printf("\n");
}

int main(void) {
  printf("%d in binary is ", 1);
  toBinary(1);
  printf("%d in binary is ", 2);
  toBinary(2);
  printf("%d in binary is ", 10);
  toBinary(10);
  printf("%d in binary is ", 1001);
  toBinary(1001);
  printf("%d in binary is ", 90250);
  toBinary(90250);  
  return 0;
}