#include <stdio.h>
int main(void)
{
 int num1;
 int num2;
 int sum;
 int difference;
 int product;
 int quotient;
 printf("Jeremie Bornais,\n110007408\n");
 printf("Enter first number: ");
 scanf("%d", &num1);
 printf("Enter second number: ");
 scanf("%d", &num2);
 sum = num1 + num2;
 difference = num1 - num2;
 product = num1 * num2;
 quotient = num1 / num2;
 printf("Sum of the entered numbers: %d\n", sum);
 printf("-----------------------------------------------------------------\n");
 printf("|\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t |\n");
 printf("|\t\t\t\t %d + %d = %d\t\t\t\t\t\t\t\t\t\t |\n", num1, num2, sum);
 printf("|\t\t\t\t %d - %d = %d\t\t\t\t\t\t\t\t\t\t |\n", num1, num2, difference);
 printf("|\t\t\t\t %d X %d = %d\t\t\t\t\t\t\t\t\t\t |\n", num1, num2, product);
 printf("|\t\t\t\t %d / %d = %d\t\t\t\t\t\t\t\t\t\t |\n", num1, num2, quotient);
 printf("|\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t |\n");
 printf("-----------------------------------------------------------------\n");
 return 0;
}