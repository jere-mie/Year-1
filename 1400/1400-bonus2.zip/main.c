#include <stdio.h>

int main(void) {
  printf("Input a number:\n");
  int num;
  scanf("%d", &num);
  int temp = num;
  int result=0;
  while (temp!=0){
    result*=10;
    result+=temp%10;
    temp/=10;
  }
  if (num == result){
    printf("%d is a palindrome\n", num);
  }else {
    printf("%d is not a palindrome\n", num);
  }

  return 0;
}