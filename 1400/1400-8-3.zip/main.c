#include <stdio.h>
int toBinary(int n){
  int result=0;
  while(n>0){
    
    result+=n%2;
    n/=2;
    result*=10;
  }
  return result;
}
int main(void) {
  printf("%d in binary is %d\n", 1, toBinary(1));
  printf("%d in binary is %d\n", 2, toBinary(2));
  printf("%d in binary is %d\n", 10, toBinary(10));
  printf("%d in binary is %d\n", 1001, toBinary(1001));
  printf("%d in binary is %d\n", 90250, toBinary(90250));
  return 0;
}