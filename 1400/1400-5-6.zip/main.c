/*
#include <stdio.h>

int main(void) {
  printf("Hello World\n");
  return 0;
}
*/


/*
#include<stdio.h>
int main(void)
{
 int i = 0;
 while(i < 2)
 switch(i)
 {
i = 2;
case 0:
printf("Hi. This is case 0 \n");
 i++;
case 1:
printf("Hi. This is case 1 \n");
 i++;
break;
case 2:
printf("Hi. This is case 2 \n");
 i++;
break;
 default:
printf("Hi. This is default \n");
 i++;
break;
 }
}
//output:
  //Hi. This is case 0
  //Hi. This is case 1
  //no break
//why case 2 is not selected
  //while says for i<2, so case 2 is impossible
//how many iterations
  //one, since we set i to 2 right away

  */





  #include<stdio.h>
int main(void)
{
 int i = 0;
 while(i < 2)
 switch(i)
 {
i = 2;
case 0:
printf("Hi. This is case 0 \n");
 i++;
 break;
case 1:
printf("Hi. This is case 1 \n");
 i++;
break;
case 2:
printf("Hi. This is case 2 \n");
 i++;
break;
 default:
printf("Hi. This is default \n");
 i++;
break;
 }
}