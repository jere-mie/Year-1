/*
Jeremie Bornais
110007408
University of Windsor
11/13/19
COMP 1400 LAB 8
*/

#include <stdio.h>

//pi constant for area
#define pi 3.1415926


//A
float computeArea(float rad);
//B
unsigned long long int factorial(int n);
//C
void toBinary(int n);

//Main
int main(void) {

  //A
  printf("\n\nExercise A:\n");
  printf("Please enter the radius:\n");
  float radius, area;
  scanf("%f", &radius);
  area = computeArea(radius);
  printf("Area is: %f\n\n\n", area);
  
  //B
  printf("Exercise B:\n");
  printf("Factorial of %d is %llu\n", 2, factorial(2));
  printf("Factorial of %d is %llu\n", 3, factorial(3));
  printf("Factorial of %d is %llu\n", 4, factorial(4));
  printf("Factorial of %d is %llu\n", 5, factorial(5));
  printf("Factorial of %d is %llu\n", 10, factorial(10));
  printf("Factorial of %d is %llu\n\n\n", 15, factorial(15));
  //max value is 65
  //max accurate value is 20
  
  //C
  printf("Exercise C:\n");
  printf("%d in binary is ", 1);
  toBinary(1);
  printf("%d in binary is ", 2);
  toBinary(2);
  printf("%d in binary is ", 10);
  toBinary(10);
  printf("%d in binary is ", 1001);
  toBinary(1001);
  printf("%d in binary is ", 90250);
  toBinary(90250); 
  
  return 0;
}




//A
float computeArea(float rad){
  return rad*rad*pi;
}

//B
unsigned long long int factorial(int n){
  unsigned long long int ans = 1;
  //constantly multiplyying by n-i
  for (int i=0;i<n;i++){
    ans*=(n-i);
  }
  return ans;
}

//C
void toBinary(int n){
  int binary[32];//stores digits
  int i=0;//iterator
  
  //until n is 0
  while(n!=0){
    binary[i]=n%2;//taking remainder by 2
    n/=2;//dividing by 2
    i++;
  }

  //printing array backwards to print correct number
  for (int j=i-1; j>=0; j--){
    printf("%d", binary[j]);
  }
  printf("\n");
}
