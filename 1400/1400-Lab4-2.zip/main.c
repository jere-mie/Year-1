#include <stdio.h>

int main(void) {
  printf("Exercise 4\n");
    printf("Please enter 3 numbers:\n");
    int num4, num5, num6;
    scanf("%d", &num4);
    scanf("%d", &num5);
    scanf("%d", &num6);
    int min, max;
    //finding  min
    if(num4<=num5 && num4<=num6){
      min=num4;
    }
    if(num5<=num4 && num5<=num6){
      min=num5;
    }
    if(num6<=num5 && num6<=num4){
      min=num6;
    }
    //finding max
    if(num4>=num5 && num4>=num6){
      max=num4;
    }
    if(num5>=num4 && num5>=num6){
      max=num5;
    }
    if(num6>=num5 && num6>=num4){
      max=num6;
    }
    printf("Max is: %d\n", max);
    printf("Min is: %d\n", min);   
    return 0;
}