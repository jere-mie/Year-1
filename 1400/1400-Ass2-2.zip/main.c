/*
Jeremie Bornais
110007408
University of Windsor
COMP1400
Random Value Generator
*/

#include <stdio.h>
#include <stdlib.h> 
#include <time.h>

int main(void) {
  //Bonus
  //seeding the time to generate unique random numbers
  srand (time(NULL));

  //Part a) generating two random numbers from 1 to 9
  //rand() % (max_number + 1 - minimum_number) + minimum_number
  //above is the formula for setting upper and lower bounds
  int a = rand() % (9 + 1 - 1) + 1;

  int b = rand() % (9 + 1 - 1) + 1;

  //Part b) and c) generating a number from 0 to 2
  int operand = rand() % (2 + 1 - 0) + 0;
  //displaying info
  printf("Int a is: %d, Int b is: %d, Operator number is: %d\n", a, b, operand);
  //determining which operator to use depending on it
  //and performing the necessary operation
  switch (operand){
    case 0:
      //add
      printf("%d + %d = %d\n", a, b, a + b);
      break;
    case 1:
      //subtract
      printf("%d - %d = %d\n", a, b, a - b);
      break;
    case 2:
      //multiply
      printf("%d X %d = %d\n", a, b, a * b);
      break;
    
  }
  return 0;
}