#include <stdio.h>

int main(void) {
  int base, exponent;
  
  printf("What's the base:\n");
  scanf("%d", &base);
  printf("What's the base:\n");
  scanf("%d", &exponent);
  int answer=1;
  for (int i=0;i<exponent;i++){
    answer*=base;
  }

  printf("%d is the answer\n", answer);
  return 0;
}