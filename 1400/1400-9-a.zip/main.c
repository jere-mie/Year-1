#include<stdio.h>
int main(void)
{
//A
// complete this line
printf(" x = %d, y = %d, z = %d \n", 1, 2, 3);
{
// complete this line
// complete this line
printf(" x = %d, y = %f, z = %d \n", 10, 15.0, 4);
{
// complete this line
printf(" x = %d, y = %f, z = %d \n", 10, 15.0, 50);
}
}

//B
 { int x = 10;
 }
 { printf("%d", x);
 } 
/*
main.c:20:17: error: use of undeclared identifier 'x'
 { printf("%d", x);
                ^
1 error generated.
compiler exit status 1
*/

} 