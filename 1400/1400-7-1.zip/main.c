/*
Jeremie Bornais
110007408
University of Windsor
COMP 1400
Lab 7 Part 1
11/06/2019
*/
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(void) {
  //seeding rand
  srand(time(NULL));

  //declaring start and end times of type time_t
  time_t start,end;




  printf("Enter the number of elements:\n");
  int n;
  scanf("%d", &n);

  //array to be filled with random values
  int nums [n];
  

  //filling in array with random values
  for (int i=0; i<n;i++){
    nums[i] = rand();//% (10-0+1)+0; 
  }


  //temporary storage for swapping
  int temp = 0;
  
  //starting timer
  start=clock();

  //the sorting starts here
  //outer loop
  for (int l = 0; l<n-1; l++){
    //inner loop
    for (int k = 0; k<n-l-1;k++){
      //swapping numbers
      if (nums[k]>nums[k+1]){
        temp = nums[k];
        nums[k] = nums[k+1];
        nums[k+1] = temp;
      }
    }
  }
  //end timer
  end=clock();
  
  //elapsed time
  double t=(double)(end-start)*1000/CLOCKS_PER_SEC;
  
  //printing array
  printf("\n\nHere is the array:\n");
  for (int j=0; j<n;j++){
    printf("%d\n", nums[j]); 
  }
  printf("Elapsed Time: %fms", t);
  return 0;
}