/*
Jeremie Bornais
110007408
University of Windsor
COMP 1400
Lab 7 Part 2
11/06/2019
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(void) {
  //seeding rand
  srand (time(NULL));
  
  //declaring Array
  int nums[30];

  //initializing array with random values
  for (int i = 0; i<30; i++){
    nums[i] = rand() % (20 - 0 + 1) + 0;
  }

  
  int counter=0;//counts frequency
  int num;//the number we get from the user
  printf("Input a number from 0 to 20\n");
  scanf("%d", &num);

  //linear search
  for (int j = 0; j<30; j++){
    //adding one to counter if the number is in that specific spot of the array
    if (nums[j] == num){
      counter++;
    }
  }
  
  //displaying array
  printf("\n\nArray:\n");
  for (int k = 0; k<30; k++){
    printf("%d ", nums[k]);
  }

  //displaying frequency
  printf("\n\n%d occurs %d times\n",num, counter);
  return 0;
}